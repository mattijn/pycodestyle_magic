from setuptools import setup

setup(
    name='pycodestyle_magic',
    version='0.2'
    )
